#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <objc/runtime.h>

#define PREFS_DOMAIN CFSTR("com.cursorus.chaseke")
#define NOTIF CFSTR("com.cursorus.chaseke/prefschanged")
static NSString *const kFontDir = @"/var/mobile/Library/LockClockFonts";

static NSDictionary *prefs;
static NSMutableDictionary *fontMap; // file name (lowercase, no ext) -> PostScript name
static NSHashTable *views;
static const void *kOrigTimeFont = &kOrigTimeFont;
static const void *kOrigDateFont = &kOrigDateFont;

@interface SBFLockScreenDateView : UIView
@end

@interface SBUILegibilityLabel : UIView
@property (nonatomic, retain) UIFont *font;
@end

static void loadPrefs(void) {
    CFPreferencesAppSynchronize(PREFS_DOMAIN);
    NSDictionary *d = nil;
    CFArrayRef keys = CFPreferencesCopyKeyList(PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    if (keys) {
        d = (NSDictionary *)CFBridgingRelease(CFPreferencesCopyMultiple(keys, PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost));
        CFRelease(keys);
    }
    prefs = d ?: @{};
}
static BOOL B(NSString *k, BOOL def) { id v = prefs[k]; return v ? [v boolValue] : def; }
static CGFloat F(NSString *k, CGFloat def) { id v = prefs[k]; return v ? [v doubleValue] : def; }
static NSString *S(NSString *k) { id v = prefs[k]; return [v isKindOfClass:NSString.class] ? v : @""; }

static void registerFonts(void) {
    fontMap = [NSMutableDictionary new];
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:kFontDir error:nil];
    for (NSString *f in files) {
        NSString *ext = f.pathExtension.lowercaseString;
        if (![ext isEqualToString:@"ttf"] && ![ext isEqualToString:@"otf"]) continue;
        NSURL *url = [NSURL fileURLWithPath:[kFontDir stringByAppendingPathComponent:f]];
        CTFontManagerRegisterFontsForURL((__bridge CFURLRef)url, kCTFontManagerScopeProcess, NULL);
        CFArrayRef descs = CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
        if (descs && CFArrayGetCount(descs) > 0) {
            CTFontDescriptorRef d = CFArrayGetValueAtIndex(descs, 0);
            NSString *ps = CFBridgingRelease(CTFontDescriptorCopyAttribute(d, kCTFontNameAttribute));
            if (ps) fontMap[f.stringByDeletingPathExtension.lowercaseString] = ps;
        }
        if (descs) CFRelease(descs);
    }
}

static UIFont *makeFont(NSString *name, CGFloat size, UIFont *orig) {
    if (size <= 0) size = orig.pointSize;
    if (name.length) {
        NSString *ps = fontMap[name.lowercaseString] ?: name;
        UIFont *f = [UIFont fontWithName:ps size:size];
        if (f) return f;
    }
    return [orig fontWithSize:size];
}

static id kv(id o, NSString *key) {
    @try { return [o valueForKey:key]; } @catch (__unused id e) { return nil; }
}

static const void *kLastCenter = &kLastCenter;
static const void *kLastOff = &kLastOff;

// center as the system laid it out (without our offset)
static CGPoint baseOf(UIView *v) {
    CGPoint cur = v.center;
    NSValue *lc = objc_getAssociatedObject(v, kLastCenter);
    NSValue *lo = objc_getAssociatedObject(v, kLastOff);
    if (lc && lo) {
        CGPoint c = lc.CGPointValue, o = lo.CGPointValue;
        if (fabs(cur.x - c.x) < 0.5 && fabs(cur.y - c.y) < 0.5) return CGPointMake(cur.x - o.x, cur.y - o.y);
    }
    return cur;
}
static void setPos(UIView *v, CGPoint base, CGPoint off) {
    CGPoint n = CGPointMake(base.x + off.x, base.y + off.y);
    v.center = n;
    objc_setAssociatedObject(v, kLastCenter, [NSValue valueWithCGPoint:n], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(v, kLastOff, [NSValue valueWithCGPoint:off], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void applyFont(UIView *label, NSString *fontName, CGFloat size, const void *key) {
    if (!label || ![label respondsToSelector:@selector(font)] || ![label respondsToSelector:@selector(setFont:)]) return;
    SBUILegibilityLabel *l = (SBUILegibilityLabel *)label;
    UIFont *orig = objc_getAssociatedObject(l, key);
    if (!orig) { orig = l.font; if (orig) objc_setAssociatedObject(l, key, orig, OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    if (!orig) return;
    UIFont *nf = makeFont(fontName, size, orig);
    if (![nf.fontName isEqualToString:l.font.fontName] || nf.pointSize != l.font.pointSize) {
        l.font = nf;
        [l sizeToFit];
    }
}

static void restoreFont(UIView *label, const void *key) {
    UIFont *orig = label ? objc_getAssociatedObject(label, key) : nil;
    if (orig && [label respondsToSelector:@selector(setFont:)]) { [(SBUILegibilityLabel *)label setFont:orig]; [label sizeToFit]; }
}

static void apply(UIView *v) {
    UIView *timeLabel = kv(v, @"timeLabel");
    UIView *dateView = kv(v, @"dateSubtitleView");
    UIView *dateLabel = kv(dateView, @"label") ?: dateView;
    if (!timeLabel && !dateView) return;

    BOOL enabled = B(@"enabled", YES);
    BOOL together = B(@"moveTogether", YES);
    CGFloat tx = F(@"timeX", 0), ty = F(@"timeY", 0), dx = F(@"dateX", 0), dy = F(@"dateY", 0);
    if (together) { tx = dx = F(@"allX", 0); ty = dy = F(@"allY", 0); }

    if (enabled) {
        applyFont(timeLabel, S(@"timeFont"), F(@"timeSize", 0), kOrigTimeFont);
        applyFont(dateLabel, S(@"dateFont"), F(@"dateSize", 0), kOrigDateFont);
    } else {
        restoreFont(timeLabel, kOrigTimeFont);
        restoreFont(dateLabel, kOrigDateFont);
        tx = ty = dx = dy = 0;
    }

    CGPoint tb = timeLabel ? baseOf(timeLabel) : CGPointZero;
    CGPoint db = dateView ? baseOf(dateView) : CGPointZero;

    // date above the time: swap the vertical positions
    if (enabled && B(@"dateAbove", NO) && timeLabel && dateView) {
        CGFloat diff = db.y - tb.y;
        ty += diff; dy -= diff;
    }

    if (timeLabel) setPos(timeLabel, tb, CGPointMake(tx, ty));
    if (dateView) setPos(dateView, db, CGPointMake(dx, dy));

    BOOL invert = enabled && B(@"invert", NO);
    timeLabel.layer.compositingFilter = invert ? @"differenceBlendMode" : nil;
    dateLabel.layer.compositingFilter = invert ? @"differenceBlendMode" : nil;
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    loadPrefs();
    registerFonts();
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *v in views.allObjects) { apply(v); [v setNeedsLayout]; }
    });
}

%hook SBFLockScreenDateView
- (void)layoutSubviews {
    %orig;
    if (!views) views = [NSHashTable weakObjectsHashTable];
    [views addObject:self];
    apply(self);
}
%end

%ctor {
    loadPrefs();
    registerFonts();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, prefsChanged, NOTIF, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
