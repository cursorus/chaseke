#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <objc/runtime.h>

#define PREFS_DOMAIN CFSTR("com.cursorus.chaseke")
#define NOTIF CFSTR("com.cursorus.chaseke/prefschanged")
static NSString *const kFontDir = @"/var/mobile/Library/LockClockFonts";

static NSDictionary *prefs;
static NSMutableDictionary *fontMap; // file name (lowercase, no ext) -> PostScript name
static NSHashTable *views;
static const void *kOrigTimeFont = &kOrigTimeFont;
static const void *kOrigDateFont = &kOrigDateFont;

@interface SBFLockScreenDateView : UIView
@end

@interface SBUILegibilityLabel : UIView
@property (nonatomic, retain) UIFont *font;
@end

static void loadPrefs(void) {
    CFPreferencesAppSynchronize(PREFS_DOMAIN);
    NSDictionary *d = nil;
    CFArrayRef keys = CFPreferencesCopyKeyList(PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    if (keys) {
        d = (NSDictionary *)CFBridgingRelease(CFPreferencesCopyMultiple(keys, PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost));
        CFRelease(keys);
    }
    prefs = d ?: @{};
}
static BOOL B(NSString *k, BOOL def) { id v = prefs[k]; return v ? [v boolValue] : def; }
static CGFloat F(NSString *k, CGFloat def) { id v = prefs[k]; return v ? [v doubleValue] : def; }
static NSString *S(NSString *k) { id v = prefs[k]; return [v isKindOfClass:NSString.class] ? v : @""; }

static void registerFonts(void) {
    fontMap = [NSMutableDictionary new];
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:kFontDir error:nil];
    for (NSString *f in files) {
        NSString *ext = f.pathExtension.lowercaseString;
        if (![ext isEqualToString:@"ttf"] && ![ext isEqualToString:@"otf"]) continue;
        NSURL *url = [NSURL fileURLWithPath:[kFontDir stringByAppendingPathComponent:f]];
        CTFontManagerRegisterFontsForURL((__bridge CFURLRef)url, kCTFontManagerScopeProcess, NULL);
        CFArrayRef descs = CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
        if (descs && CFArrayGetCount(descs) > 0) {
            CTFontDescriptorRef d = CFArrayGetValueAtIndex(descs, 0);
            NSString *ps = CFBridgingRelease(CTFontDescriptorCopyAttribute(d, kCTFontNameAttribute));
            if (ps) fontMap[f.stringByDeletingPathExtension.lowercaseString] = ps;
        }
        if (descs) CFRelease(descs);
    }
}

static UIFont *makeFont(NSString *name, CGFloat size, UIFont *orig) {
    if (size <= 0) size = orig.pointSize;
    if (name.length) {
        NSString *ps = fontMap[name.lowercaseString] ?: name;
        UIFont *f = [UIFont fontWithName:ps size:size];
        if (f) return f;
    }
    return [orig fontWithSize:size];
}

static id kv(id o, NSString *key) {
    @try { return [o valueForKey:key]; } @catch (__unused id e) { return nil; }
}

static void applyToLabel(UIView *label, NSString *fontName, CGFloat size, const void *key, BOOL invert, CGAffineTransform t) {
    if (!label) return;
    if ([label respondsToSelector:@selector(font)] && [label respondsToSelector:@selector(setFont:)]) {
        SBUILegibilityLabel *l = (SBUILegibilityLabel *)label;
        UIFont *orig = objc_getAssociatedObject(l, key);
        if (!orig) { orig = l.font; if (orig) objc_setAssociatedObject(l, key, orig, OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        if (orig) {
            UIFont *nf = makeFont(fontName, size, orig);
            if (![nf.fontName isEqualToString:l.font.fontName] || nf.pointSize != l.font.pointSize) {
                l.font = nf;
                [l sizeToFit];
            }
        }
    }
    label.layer.compositingFilter = invert ? @"differenceBlendMode" : nil;
    label.transform = t;
}

static void restoreLabel(UIView *label, const void *key) {
    if (!label) return;
    UIFont *orig = objc_getAssociatedObject(label, key);
    if (orig && [label respondsToSelector:@selector(setFont:)]) { [(SBUILegibilityLabel *)label setFont:orig]; [label sizeToFit]; }
    label.layer.compositingFilter = nil;
    label.transform = CGAffineTransformIdentity;
}

static void apply(UIView *v) {
    UIView *timeLabel = kv(v, @"timeLabel");
    UIView *dateView = kv(v, @"dateSubtitleView");
    UIView *dateLabel = kv(dateView, @"label") ?: dateView;
    if (!timeLabel && !dateView) return;

    if (!B(@"enabled", YES)) {
        restoreLabel(timeLabel, kOrigTimeFont);
        restoreLabel(dateLabel, kOrigDateFont);
        if (dateView != dateLabel) dateView.transform = CGAffineTransformIdentity;
        return;
    }

    BOOL together = B(@"moveTogether", YES);
    CGFloat tx = F(@"timeX", 0), ty = F(@"timeY", 0), dx = F(@"dateX", 0), dy = F(@"dateY", 0);
    if (together) { tx = dx = F(@"allX", 0); ty = dy = F(@"allY", 0); }

    // swap vertical positions if date should be above the time
    if (B(@"dateAbove", NO) && timeLabel && dateView) {
        CGFloat diff = dateView.center.y - timeLabel.center.y;
        ty += diff; dy -= diff;
    }

    BOOL invert = B(@"invert", NO);
    applyToLabel(timeLabel, S(@"timeFont"), F(@"timeSize", 0), kOrigTimeFont, invert, CGAffineTransformMakeTranslation(tx, ty));
    // date: transform goes on the container, font on the inner label
    applyToLabel(dateLabel, S(@"dateFont"), F(@"dateSize", 0), kOrigDateFont, invert, dateLabel == dateView ? CGAffineTransformMakeTranslation(dx, dy) : CGAffineTransformIdentity);
    if (dateView != dateLabel) dateView.transform = CGAffineTransformMakeTranslation(dx, dy);
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    loadPrefs();
    registerFonts();
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *v in views.allObjects) { apply(v); [v setNeedsLayout]; }
    });
}

%hook SBFLockScreenDateView
- (void)layoutSubviews {
    %orig;
    if (!views) views = [NSHashTable weakObjectsHashTable];
    [views addObject:self];
    apply(self);
}
%end

%ctor {
    loadPrefs();
    registerFonts();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, prefsChanged, NOTIF, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
