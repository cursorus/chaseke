#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

#define PREFS_DOMAIN CFSTR("com.cursorus.chaseke")
#define NOTIF CFSTR("com.cursorus.chaseke/prefschanged")

static NSDictionary *prefs;
static NSMutableDictionary *fontMap; // file name (lowercase, no ext) -> PostScript name
static NSHashTable *views;
static const void *kOrigTimeFont = &kOrigTimeFont;
static const void *kOrigDateFont = &kOrigDateFont;
static const void *kLastCenter = &kLastCenter;
static const void *kLastOff = &kLastOff;
static const void *kInvView = &kInvView;

@interface CAFilter : NSObject
+ (instancetype)filterWithType:(NSString *)type;
@end

@interface UIView (ChasekePrivate)
- (NSString *)recursiveDescription;
@end
@interface UIWindow (ChasekePrivate)
+ (NSArray *)allWindowsIncludingInternalWindows:(BOOL)a onlyVisibleWindows:(BOOL)b;
@end

@interface SBFLockScreenDateView : UIView
@end
@interface NCNotificationListSectionRevealHintView : UIView
@end
@interface SBUILegibilityLabel : UIView
@property (nonatomic, retain) UIFont *font;
@end

// ---------- prefs ----------
static void loadPrefs(void) {
    CFPreferencesAppSynchronize(PREFS_DOMAIN);
    NSDictionary *d = nil;
    CFArrayRef keys = CFPreferencesCopyKeyList(PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    if (keys) {
        d = (NSDictionary *)CFBridgingRelease(CFPreferencesCopyMultiple(keys, PREFS_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost));
        CFRelease(keys);
    }
    prefs = d ?: @{};
}
static BOOL B(NSString *k, BOOL def) { id v = prefs[k]; return v ? [v boolValue] : def; }
static CGFloat F(NSString *k, CGFloat def) { id v = prefs[k]; return v ? [v doubleValue] : def; }
static NSString *S(NSString *k) { id v = prefs[k]; return [v isKindOfClass:NSString.class] ? v : @""; }

// nil = system look (default theme)
static NSDictionary *cfg(void) {
    NSString *t = S(@"theme");
    if ([t isEqualToString:@"tall"]) {
        return @{@"tf":@"tall", @"df":@"", @"ts":@220, @"ds":@0, @"tx":@0, @"ty":@-35, @"dx":@0, @"dy":@-100};
    }
    if ([t isEqualToString:@"custom"]) {
        return @{@"tf":S(@"timeFont"), @"df":S(@"dateFont"), @"ts":@(F(@"timeSize", 0)), @"ds":@(F(@"dateSize", 0)),
                 @"tx":@(F(@"timeX", 0)), @"ty":@(F(@"timeY", 0)), @"dx":@(F(@"dateX", 0)), @"dy":@(F(@"dateY", 0))};
    }
    return nil;
}

// ---------- fonts ----------
static void registerFonts(void) {
    fontMap = [NSMutableDictionary new];
    for (NSString *dir in @[@"/var/mobile/Library/LockClockFonts", @"/Library/Chaseke"]) {
        NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:nil];
        for (NSString *f in files) {
            NSString *ext = f.pathExtension.lowercaseString;
            if (![ext isEqualToString:@"ttf"] && ![ext isEqualToString:@"otf"]) continue;
            NSURL *url = [NSURL fileURLWithPath:[dir stringByAppendingPathComponent:f]];
            CTFontManagerRegisterFontsForURL((__bridge CFURLRef)url, kCTFontManagerScopeProcess, NULL);
            CFArrayRef descs = CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
            if (descs && CFArrayGetCount(descs) > 0) {
                CTFontDescriptorRef d = CFArrayGetValueAtIndex(descs, 0);
                NSString *ps = CFBridgingRelease(CTFontDescriptorCopyAttribute(d, kCTFontNameAttribute));
                if (ps) fontMap[f.stringByDeletingPathExtension.lowercaseString] = ps;
            }
            if (descs) CFRelease(descs);
        }
    }
}

static UIFont *makeFont(NSString *name, CGFloat size, UIFont *orig) {
    if (size <= 0) size = orig.pointSize;
    if (name.length) {
        NSString *ps = fontMap[name.lowercaseString] ?: name;
        UIFont *f = [UIFont fontWithName:ps size:size];
        if (f) return f;
    }
    return [orig fontWithSize:size];
}

static id kv(id o, NSString *key) {
    @try { return [o valueForKey:key]; } @catch (__unused id e) { return nil; }
}

// ---------- positioning (center offsets) ----------
static CGPoint baseOf(UIView *v) {
    CGPoint cur = v.center;
    NSValue *lc = objc_getAssociatedObject(v, kLastCenter);
    NSValue *lo = objc_getAssociatedObject(v, kLastOff);
    if (lc && lo) {
        CGPoint c = lc.CGPointValue, o = lo.CGPointValue;
        if (fabs(cur.x - c.x) < 0.5 && fabs(cur.y - c.y) < 0.5) return CGPointMake(cur.x - o.x, cur.y - o.y);
    }
    return cur;
}
static void setPos(UIView *v, CGPoint base, CGPoint off) {
    CGPoint n = CGPointMake(base.x + off.x, base.y + off.y);
    if (fabs(v.center.x - n.x) > 0.01 || fabs(v.center.y - n.y) > 0.01) v.center = n;
    objc_setAssociatedObject(v, kLastCenter, [NSValue valueWithCGPoint:n], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(v, kLastOff, [NSValue valueWithCGPoint:off], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void applyFont(UIView *label, NSString *fontName, CGFloat size, const void *key) {
    if (!label || ![label respondsToSelector:@selector(font)] || ![label respondsToSelector:@selector(setFont:)]) return;
    SBUILegibilityLabel *l = (SBUILegibilityLabel *)label;
    UIFont *orig = objc_getAssociatedObject(l, key);
    if (!orig) { orig = l.font; if (orig) objc_setAssociatedObject(l, key, orig, OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    if (!orig) return;
    UIFont *nf = makeFont(fontName, size, orig);
    if (![nf.fontName isEqualToString:l.font.fontName] || nf.pointSize != l.font.pointSize) {
        l.font = nf;
        [l sizeToFit];
    }
}
static void restoreFont(UIView *label, const void *key) {
    UIFont *orig = label ? objc_getAssociatedObject(label, key) : nil;
    if (!orig || ![label respondsToSelector:@selector(setFont:)]) return;
    SBUILegibilityLabel *l = (SBUILegibilityLabel *)label;
    if (![orig.fontName isEqualToString:l.font.fontName] || orig.pointSize != l.font.pointSize) {
        l.font = orig;
        [l sizeToFit];
    }
}

// views like "Charging 45%" that live outside the date view
static void collect(UIView *root, NSMutableArray *out, int depth) {
    if (depth > 5) return;
    NSString *n = NSStringFromClass(root.class);
    if ([n rangeOfString:@"Charging" options:NSCaseInsensitiveSearch].location != NSNotFound) { [out addObject:root]; return; }
    for (UIView *s in root.subviews) collect(s, out, depth + 1);
}
static NSArray *chargingViews(UIView *v) {
    NSMutableArray *out = [NSMutableArray array];
    UIView *root = v.superview.superview ?: v.superview;
    if (root) collect(root, out, 0);
    NSMutableArray *res = [NSMutableArray array];
    for (UIView *c in out) {
        if ([c isDescendantOfView:v] || [v isDescendantOfView:c]) continue;
        [res addObject:c];
    }
    return res;
}

// ---------- inversion: backdrop layer + colorInvert, masked by the text ----------
@interface ChaInvertView : UIView
@end
@implementation ChaInvertView
+ (Class)layerClass {
    Class c = NSClassFromString(@"CABackdropLayer");
    return c ?: [CALayer class];
}
- (instancetype)initWithFrame:(CGRect)f {
    self = [super initWithFrame:f];
    if (self) {
        self.userInteractionEnabled = NO;
        Class fc = NSClassFromString(@"CAFilter");
        if (fc) {
            id flt = [fc filterWithType:@"colorInvert"];
            if (flt) self.layer.filters = @[flt];
        }
        @try {
            [self.layer setValue:@YES forKey:@"windowServerAware"];
            [self.layer setValue:@1 forKey:@"scale"];
        } @catch (__unused id e) {}
    }
    return self;
}
@end

static void updateInvert(UIView *host, UIView *label, BOOL on) {
    if (!label) return;
    ChaInvertView *iv = objc_getAssociatedObject(label, kInvView);
    if (!on) {
        if (iv) {
            [iv removeFromSuperview];
            objc_setAssociatedObject(label, kInvView, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            label.alpha = 1;
        }
        return;
    }
    CGSize sz = label.bounds.size;
    if (sz.width < 1 || sz.height < 1) return;
    label.alpha = 1; // make sure the text is rendered into the mask
    UIGraphicsBeginImageContextWithOptions(sz, NO, 0);
    [label.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    if (!iv) {
        iv = [[ChaInvertView alloc] initWithFrame:CGRectZero];
        iv.maskView = [[UIImageView alloc] init];
        objc_setAssociatedObject(label, kInvView, iv, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (iv.superview != host) [host addSubview:iv];
    CGRect r = [host convertRect:label.bounds fromView:label];
    if (!CGRectEqualToRect(iv.frame, r)) iv.frame = r;
    iv.maskView.frame = iv.bounds;
    ((UIImageView *)iv.maskView).image = img;
    label.alpha = 0;
}

// ---------- main ----------
static void apply(UIView *v) {
    UIView *timeLabel = kv(v, @"timeLabel");
    UIView *dateView = kv(v, @"dateSubtitleView");
    UIView *dateLabel = kv(dateView, @"label") ?: dateView;
    if (!timeLabel && !dateView) return;

    NSDictionary *c = cfg();
    CGFloat tx = 0, ty = 0, dx = 0, dy = 0;
    if (c) {
        applyFont(timeLabel, c[@"tf"], [c[@"ts"] doubleValue], kOrigTimeFont);
        applyFont(dateLabel, c[@"df"], [c[@"ds"] doubleValue], kOrigDateFont);
        tx = [c[@"tx"] doubleValue]; ty = [c[@"ty"] doubleValue];
        dx = [c[@"dx"] doubleValue]; dy = [c[@"dy"] doubleValue];
    } else {
        restoreFont(timeLabel, kOrigTimeFont);
        restoreFont(dateLabel, kOrigDateFont);
    }

    if (timeLabel) setPos(timeLabel, baseOf(timeLabel), CGPointMake(tx, ty));
    if (dateView) setPos(dateView, baseOf(dateView), CGPointMake(dx, dy));
    for (UIView *cv in chargingViews(v)) setPos(cv, baseOf(cv), CGPointMake(dx, dy));

    BOOL inv = B(@"invert", NO);
    updateInvert(v, timeLabel, inv);
    if (dateLabel != timeLabel) updateInvert(v, dateLabel, inv);
}

static void dumpHierarchy(void) {
    NSMutableString *s = [NSMutableString string];
    NSArray *wins = [UIWindow allWindowsIncludingInternalWindows:YES onlyVisibleWindows:NO];
    for (UIWindow *w in wins) {
        [s appendFormat:@"=== %@\n", w];
        NSString *d = [w recursiveDescription];
        if (d) [s appendString:d];
        [s appendString:@"\n\n"];
    }
    [s writeToFile:@"/var/mobile/chaseke_dump.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

static void prefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    loadPrefs();
    registerFonts();
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *v in views.allObjects) { apply(v); [v setNeedsLayout]; }
        if (B(@"debugDump", NO)) dumpHierarchy();
    });
}

%hook SBFLockScreenDateView
- (void)layoutSubviews {
    %orig;
    if (!views) views = [NSHashTable weakObjectsHashTable];
    [views addObject:self];
    apply(self);
}
%end

// "No Older Notifications"
%hook NCNotificationListSectionRevealHintView
- (void)didMoveToWindow {
    %orig;
    if (B(@"hideOlder", NO)) self.hidden = YES;
}
- (void)setHidden:(BOOL)h {
    %orig(B(@"hideOlder", NO) ? YES : h);
}
- (void)setAlpha:(CGFloat)a {
    %orig(B(@"hideOlder", NO) ? 0 : a);
}
%end

%ctor {
    loadPrefs();
    registerFonts();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, prefsChanged, NOTIF, NULL, CFNotificationSuspensionBehaviorCoalesce);
    // keep the inverted text in sync when the time changes
    [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(NSTimer *t) {
        if (!B(@"invert", NO)) return;
        for (UIView *v in views.allObjects) {
            if (!v.window) continue;
            apply(v);
        }
    }];
}
